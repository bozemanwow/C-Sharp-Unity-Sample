﻿using UnityEngine;
using System.Collections;

public class SimpleEnemyMovement : MonoBehaviour {
    public Transform[] mTravelToPoints;
    public float mSpeed;
    public float mDistance;
    int mcount = 0;
	// Update is called once per frame
	void FixedUpdate () {
        if(Vector3.Distance(transform.position, mTravelToPoints[mcount].position) > mDistance)
        transform.position = Vector3.Lerp(transform.position, mTravelToPoints[mcount].position, mSpeed*Time.deltaTime);
        else
        {
            mcount++;
            if(mTravelToPoints.Length <= mcount)
            {
                mcount = 0;
            }
        }

	}
}
