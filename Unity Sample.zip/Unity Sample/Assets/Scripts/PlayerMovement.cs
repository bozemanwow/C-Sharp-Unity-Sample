﻿using UnityEngine;
using System.Collections;

public class PlayerMovement : MonoBehaviour {
    public Rigidbody mrig;
    public float mSpeed;
	// Use this for initialization
	void Start () {
        if (mrig == null)
        {
            mrig = gameObject.GetComponent<Rigidbody>();
        }
    }

   
    void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");

        Vector3 movement = new Vector3(moveHorizontal, 0.0f, moveVertical);
        mrig.AddForce( movement * mSpeed);

        mrig.velocity = new Vector3
        (
            Mathf.Clamp(mrig.velocity.x, -mSpeed,  mSpeed),
            Mathf.Clamp(mrig.velocity.y, -mSpeed, mSpeed),
            Mathf.Clamp(mrig.velocity.z, -mSpeed,  mSpeed)
        );

     //   mrig.rotation = Quaternion.Euler(0.0f, 0.0f, mrig.velocity.x * -tilt);
    }
}
