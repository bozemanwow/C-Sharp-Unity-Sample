﻿using UnityEngine;
using System.Collections;

public class TurrentControl : MonoBehaviour {

    public float mSpeed = 3.0f;

    public Transform mTarget = null;
 
    Quaternion mLookAtRotation;
   
	// Update is called once per frame
	void FixedUpdate () {
        if (mTarget != null)
        {
            if (mTarget.gameObject.activeInHierarchy)
            {
                mLookAtRotation = Quaternion.LookRotation(mTarget.position - transform.position);
                transform.rotation = Quaternion.RotateTowards(transform.rotation, mLookAtRotation, mSpeed);
            }
        }

    }
    public void SetTarget(Transform _target)
    {
        mTarget = _target;
    }
}
