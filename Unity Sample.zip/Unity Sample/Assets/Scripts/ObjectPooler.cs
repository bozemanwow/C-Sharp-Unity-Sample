﻿using UnityEngine;


public class ObjectPooler : MonoBehaviour
{
    public string Description;
    public GameObject mObjectToPool;
    
   // set size in gameobject editor
   public GameObject[] mPoolofObjects;
    // Use this for initialization
    void Start()
    {
       
        FillArray();
    }


    public GameObject GetReadyGameObjasGameObject()
    {
        for (int count = 0; count < mPoolofObjects.Length; count++)
        {
            if (!mPoolofObjects[count].activeInHierarchy)
            {
                mPoolofObjects[count].SetActive(true);
                return mPoolofObjects[count];
            }
        }
        return null;
    }
    public Comp GetReadyGameObjasCompnent<Comp>()
    {
        GameObject TempObj = GetReadyGameObjasGameObject();
        if(TempObj != null)
        {
            return TempObj.GetComponent<Comp>();
            
        }
        return default(Comp);
    }
    public void DestoryObjsandReplaceArray(int _Amount, GameObject _ObjectToSpawn)
    {
        DestoryContents();
        mPoolofObjects = new GameObject[_Amount];
        mObjectToPool = _ObjectToSpawn;
        FillArray();
    }
    public void FillArray()
    {
        for (int count = 0; count < mPoolofObjects.Length; count++)
        {
            mPoolofObjects[count] = Instantiate(mObjectToPool) as GameObject;
            mPoolofObjects[count].SetActive(false);
        }
    }
    public void DestoryContents()
    {
        for (int count = 0; count < mPoolofObjects.Length; count++)
        {
            if (mPoolofObjects[count] != null)
                Destroy(mPoolofObjects[count]);
        }
    }
}
