﻿using UnityEngine;
using System.Collections;

public class LoadLevelScript : MonoBehaviour {


    public string mLevelToLoad;
	// Update is called once per frame
	void Update () {
        if (!Input.GetKeyDown(KeyCode.Escape))
        {
            if(Input.anyKeyDown)
            Application.LoadLevel(mLevelToLoad);
        }
    }
}
