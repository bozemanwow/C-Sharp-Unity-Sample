﻿using UnityEngine;

public class PlayerGun : MonoBehaviour
{
    public Transform mFireLocation,mSight;
    public float mShotForce, mShotTimer;
   
    public ObjectPooler mBulletPool;
    GameObject mtempBullet;
    // Update is called once per frame
    void Start()
    {
        InvokeRepeating("FireGunAutoMaticly",0.0f, mShotTimer);
    }
        
    void FireGunAutoMaticly()
    {
        mtempBullet = mBulletPool.GetReadyGameObjasGameObject();
        if (mtempBullet != null)
        {
            mtempBullet.GetComponent<BulletScript>().ShootTowards(mSight, mFireLocation.position, mShotForce);
        }
    }
}
