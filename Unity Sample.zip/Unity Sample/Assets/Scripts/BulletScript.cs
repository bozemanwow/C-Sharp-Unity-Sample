﻿using UnityEngine;


public class BulletScript : MonoBehaviour {
    public Rigidbody mrig;
    public string mnonTarget;
    public float mTimeStop;
	// Use this for initialization
	void Start () {

        if (mrig == null)
        {
            mrig = gameObject.GetComponent<Rigidbody>();
        }
       

    }
	public void ShootTowards(Transform _Targetpos,Vector3 _StartPos, float _force)
    {
        Invoke("StopBullet", mTimeStop);
        transform.position = _StartPos;
        transform.LookAt(_Targetpos);
        mrig.AddForce(transform.forward.normalized * _force);
    }
	void StopBullet()
    {
        if(IsInvoking("StopBullet"))
        {
            CancelInvoke("StopBullet");
        }
        gameObject.SetActive(false);
        mrig.velocity = Vector3.zero;
    }
   
    void OnTriggerEnter(Collider other)
    {
       if(!other.CompareTag(mnonTarget) )
        {
            StopBullet();
            other.gameObject.SendMessage("TakeHit", SendMessageOptions.DontRequireReceiver);
        }
    }
}
