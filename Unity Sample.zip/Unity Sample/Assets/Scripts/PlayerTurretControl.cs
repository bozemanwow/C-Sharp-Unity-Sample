﻿using UnityEngine;
using System.Collections;

public class PlayerTurretControl : MonoBehaviour {
    public TurrentControl Turrets;
   
    RaycastHit mhit;
    public Transform mManuelTarget;
    Ray mray ;
   
	
	// Update is called once per frame
	void Update () {
        if (Input.GetAxis("Fire1") > 0)
        {
            mray = Camera.main.ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(mray, out mhit))
            {
             if(mhit.collider.gameObject.CompareTag("Enemy"))
                Turrets.SetTarget(mhit.collider.gameObject.transform);
            }
        }
        else if (Input.GetAxis("Fire2") > 0)
        {
            mray = Camera.main.ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(mray, out mhit))
            {
                mManuelTarget.position = mhit.point;
                Turrets.SetTarget(mManuelTarget);
            }
        }
    }
}
